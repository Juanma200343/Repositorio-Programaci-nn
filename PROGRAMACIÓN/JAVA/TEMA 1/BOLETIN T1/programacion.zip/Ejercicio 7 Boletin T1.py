Numero1 = int(input("Dame un Numero"))
Numero2 = int(input("Dame otro Numero"))
print (Numero1) = 1
print (Numero2) = -1
if Numero1 >0 :
if Numero2 >0 :
    print ("Positivo")