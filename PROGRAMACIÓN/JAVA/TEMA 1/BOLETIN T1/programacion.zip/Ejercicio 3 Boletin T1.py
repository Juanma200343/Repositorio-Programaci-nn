int(input("Dame un Numero"))
Nº1 = 33  
Nº2 = 4
Resultado = ( Nº1 * Nº2)
print = Resultado
