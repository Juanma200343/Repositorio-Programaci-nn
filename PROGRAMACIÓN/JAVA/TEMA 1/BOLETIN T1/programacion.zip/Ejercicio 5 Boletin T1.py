Numero1 = int(input("-2"))
if Numero1 >0 :
    print ("Es positivo")
if Numero1 <   0 :
    print ("Es Negativo") 