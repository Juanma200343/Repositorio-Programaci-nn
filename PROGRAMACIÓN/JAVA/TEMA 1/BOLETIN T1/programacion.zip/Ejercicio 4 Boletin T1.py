Numero1 = int(input("Dame un Numero"))
int = Numero1 = "3"
if Numero1 >0:
    print ("Es positivo")