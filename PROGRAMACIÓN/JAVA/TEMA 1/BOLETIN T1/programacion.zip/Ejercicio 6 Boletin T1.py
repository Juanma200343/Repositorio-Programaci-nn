Numero1 = int(input("Dame un Numero"))
Numero1 = 0 
if Numero1 >0 :
    print ("Es positivo")
elif Numero1 <0 :
    print ("Es Negativo")
else: 
    print ("Cero")