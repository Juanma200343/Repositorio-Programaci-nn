print ("El resultado es")
Resultado = int ("37/5,3")
print = Resultado 
